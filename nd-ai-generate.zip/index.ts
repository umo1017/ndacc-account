
import { createClient } from "npm:@supabase/supabase-js@2";

const TEXT_MODEL = Deno.env.get("TEXT_MODEL") || "gpt-4.1-mini";
const IMAGE_MODEL = Deno.env.get("IMAGE_MODEL") || "gpt-image-1";

const BUCKET = "ai-posters";
const FONT_PATH = "system/fonts/chinese.ttf";

const W = 1080;
const H = 1350;

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const PALETTES = [
  "champagne gold, ivory and warm beige",
  "deep emerald, cream and soft gold",
  "dusty rose, pearl and champagne",
  "midnight navy, silver and mist grey",
  "warm terracotta, sand and natural linen",
  "soft lavender, pearl and muted gold",
];

const uuid = (v: unknown) =>
  typeof v === "string" &&
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);

const response = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: {
      ...CORS,
      "Content-Type": "application/json; charset=utf-8",
    },
  });

const errText = (e: unknown) =>
  e instanceof Error ? e.message : String(e);

const esc = (s: unknown) =>
  String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");

const b64 = (bytes: Uint8Array) => {
  let s = "";

  for (let i = 0; i < bytes.length; i += 8192) {
    s += String.fromCharCode(
      ...bytes.subarray(i, i + 8192)
    );
  }

  return btoa(s);
};

const fromB64 = (value: string) =>
  Uint8Array.from(
    atob(value),
    (c) => c.charCodeAt(0)
  );

function jsonFromAI(s: string): any {
  try {
    return JSON.parse(s);
  } catch {
    const m = s.match(/\{[\s\S]*\}/);

    if (!m) {
      throw new Error("AI did not return JSON");
    }

    return JSON.parse(m[0]);
  }
}

async function openai(
  path: string,
  body: Record<string, unknown>,
  key: string
) {
  const r = await fetch(
    `https://api.openai.com/v1${path}`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    }
  );

  const raw = await r.text();
  let data: any;

  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error(
      `OpenAI HTTP ${r.status}: ${raw.slice(0, 300)}`
    );
  }

  if (!r.ok) {
    throw new Error(
      `OpenAI HTTP ${r.status} ` +
      `(${data.error?.code || "error"}): ` +
      `${data.error?.message || raw.slice(0, 300)}`
    );
  }

  return data;
}

function aiText(r: any): string {
  if (typeof r.output_text === "string") {
    return r.output_text;
  }

  return (r.output || [])
    .flatMap((x: any) => x.content || [])
    .filter((x: any) => x.type === "output_text")
    .map((x: any) => x.text || "")
    .join("\n");
}

async function image(
  prompt: string,
  key: string
): Promise<Uint8Array> {
  const result = await openai(
    "/images/generations",
    {
      model: IMAGE_MODEL,
      prompt,
      size: "1024x1536",
      quality: "high",
      n: 1,
      output_format: "png",
    },
    key
  );

  if (!result.data?.[0]?.b64_json) {
    throw new Error(
      "Image response did not contain b64_json"
    );
  }

  return fromB64(result.data[0].b64_json);
}

async function download(
  db: any,
  path: string
): Promise<Uint8Array> {
  const { data, error } = await db.storage
    .from(BUCKET)
    .download(path);

  if (error || !data) {
    throw new Error(
      `Storage download ${path}: ` +
      (error?.message || "missing")
    );
  }

  return new Uint8Array(
    await data.arrayBuffer()
  );
}

async function upload(
  db: any,
  path: string,
  bytes: Uint8Array
) {
  const { error } = await db.storage
    .from(BUCKET)
    .upload(path, bytes, {
      upsert: true,
      contentType: "image/png",
      cacheControl: "0",
    });

  if (error) {
    throw new Error(
      `Storage upload ${path}: ${error.message}`
    );
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: CORS,
    });
  }

  if (req.method !== "POST") {
    return response(
      { ok: false, error: "POST only" },
      405
    );
  }

  const url =
    Deno.env.get("SUPABASE_URL") || "";

  const anon =
    Deno.env.get("SUPABASE_ANON_KEY") || "";

  const service =
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";

  const apiKey =
    Deno.env.get("OPENAI_API_KEY") || "";

  const admins = (
    Deno.env.get("AI_ADMIN_EMAILS") || ""
  )
    .split(",")
    .map((x) => x.trim().toLowerCase())
    .filter(Boolean);

  if (
    !url ||
    !anon ||
    !service ||
    !apiKey ||
    !admins.length
  ) {
    return response(
      {
        ok: false,
        error: "Missing backend secrets",
      },
      503
    );
  }

  const token = (
    req.headers.get("authorization") || ""
  ).replace(/^Bearer\s+/i, "");

  if (!token) {
    return response(
      { ok: false, error: "Login required" },
      401
    );
  }

  const authDb = createClient(url, anon, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  const {
    data: auth,
    error: authError,
  } = await authDb.auth.getUser(token);

  if (authError || !auth.user?.email) {
    return response(
      { ok: false, error: "Invalid login" },
      401
    );
  }

  if (
    !admins.includes(
      auth.user.email.toLowerCase()
    )
  ) {
    return response(
      {
        ok: false,
        error: "Admin access required",
      },
      403
    );
  }

  let jobId: string;
  let action = "generate";

  try {
    const body = await req.json();
    jobId = String(body.job_id || "");
    action = String(body.action || "generate");
  } catch {
    return response(
      { ok: false, error: "Invalid JSON" },
      400
    );
  }

  if (!uuid(jobId)) {
    return response(
      { ok: false, error: "Invalid job_id" },
      400
    );
  }

  const db = createClient(url, service, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  if (action === "resume") {
    try {
      const {data:job,error:je}=await db.from("ai_content_jobs").select("id,brand_id,content_date,status").eq("id",jobId).single();
      if(je||!job||job.status!=="checking")return response({ok:false,error:"Task not awaiting browser composition"},409);
      const {data:assets,error:ae}=await db.from("ai_generated_assets").select("qa_result,caption").eq("job_id",jobId).order("version",{ascending:false}).limit(1);
      if(ae||!assets?.length)throw new Error(ae?.message||"Pending assets not found");
      const qa=assets[0].qa_result||{};
      if(!qa.composition_pending)throw new Error("Composition already completed");
      const prefix=`${job.brand_id}/${job.content_date}/${jobId}`;
      const coverPath=`${prefix}/cover.png`;
      const coverSign=await db.storage.from(BUCKET).createSignedUploadUrl(coverPath,{upsert:true});
      if(coverSign.error)throw new Error(coverSign.error.message);
      return response({ok:true,status:"checking",job_id:jobId,
        cover_background_path:qa.cover_background_path,
        logo_path:qa.logo_path,cover_path:coverPath,
        cover_upload_token:coverSign.data.token,
        poster_copy:qa.poster_copy,caption:assets[0].caption});
    }catch(e){return response({ok:false,error:errText(e)},500);}
  }

  // Finalize only after the browser-composited single poster exists in private Storage.
  if (action === "finalize") {
    try {
      const { data: job, error: je } = await db.from("ai_content_jobs")
        .select("id,brand_id,content_date,status").eq("id", jobId).single();
      if (je || !job || job.status !== "checking") return response({ ok:false, error:"Job not awaiting composition" }, 409);
      const prefix = `${job.brand_id}/${job.content_date}/${jobId}`;
      const paths = [`${prefix}/cover.png`];
      const { data: objects, error: le } = await db.storage.from(BUCKET).list(prefix, { limit:100 });
      if (le) throw le;
      for (const path of paths) {
        const file = (objects || []).find((x:any) => x.name === path.split("/").pop());
        if (!file || Number(file.metadata?.size || 0) < 10000) throw new Error(`Final poster missing: ${path}`);
      }
      const { data: rows, error: ae } = await db.from("ai_generated_assets")
        .select("id,qa_result").eq("job_id",jobId).order("version",{ascending:false}).limit(1);
      if (ae || !rows?.length) throw new Error(ae?.message || "Assets missing");

      const asset = rows[0];
      const { error: ue } = await db.from("ai_generated_assets").update({
        qa_status:"review",
        qa_result:{ ...(asset.qa_result || {}), composition_pending:false, requires_manual_approval:true, ready_to_publish:false, composed_at:new Date().toISOString() }
      }).eq("id",asset.id);
      if (ue) throw ue;
      const { error: fe } = await db.from("ai_content_jobs").update({status:"needs_review",error_message:null,updated_at:new Date().toISOString()}).eq("id",jobId).eq("status","checking");
      if (fe) throw fe;
      return response({ok:true,job_id:jobId,status:"needs_review"});
    } catch(e) { return response({ok:false,error:errText(e)},500); }
  }

  let stage = "LOAD_JOB";
  let claimed = false;

  try {
    const {
      data: job,
      error: jobError,
    } = await db
      .from("ai_content_jobs")
      .select(
        "id,brand_id,content_date,status,topic_id"
      )
      .eq("id", jobId)
      .single();

    if (jobError || !job) {
      throw new Error(
        jobError?.message || "Job not found"
      );
    }

    if (
      ![
        "planned",
        "failed",
      ].includes(job.status)
    ) {
      return response(
        {
          ok: false,
          error:
            `Job status not eligible: ${job.status}`,
        },
        409
      );
    }

    stage = "LOAD_BRAND";

    const {
      data: brand,
      error: brandError,
    } = await db
      .from("ai_brand_settings")
      .select("master_prompt,logo_path")
      .eq("brand_id", job.brand_id)
      .single();

    if (
      brandError ||
      !brand?.master_prompt
    ) {
      throw new Error(
        brandError?.message ||
          "Brand master prompt missing"
      );
    }

    const expectedLogo =
      `brands/${job.brand_id}/`;

    if (
      !brand.logo_path?.startsWith(
        expectedLogo
      ) ||
      !/^logo\.(png|jpg|jpeg|webp)$/i.test(
        brand.logo_path.slice(
          expectedLogo.length
        )
      )
    ) {
      throw new Error(
        "Official logo must be stored under " +
        "brands/<brand_id>/logo.png " +
        "(or jpg/webp)"
      );
    }

    stage = "LOAD_ASSETS";


    // Browser performs font rendering; no font needed in Edge Function.

    stage = "LOAD_CONTENT_TYPES";

    const {
      data: types,
      error: typesError,
    } = await db
      .from("ai_content_types")
      .select(
        "id,name,description,custom_prompt," +
        "allow_price,allow_promotion," +
        "allow_booking_info,weekly_quota," +
        "is_active,sort_order"
      )
      .eq("brand_id", job.brand_id)
      .eq("is_active", true)
      .order("sort_order", {
        ascending: true,
      })
      .order("name", {
        ascending: true,
      });

    if (typesError) {
      throw typesError;
    }

    const allocations = (
      types || []
    ).flatMap((type: any) =>
      Array.from(
        {
          length:
            Number(type.weekly_quota) || 0,
        },
        () => type
      )
    );

    if (allocations.length !== 7) {
      throw new Error(
        `Weekly quotas must total 7, ` +
        `got ${allocations.length}`
      );
    }

    const weekday = new Date(
      `${job.content_date}T12:00:00Z`
    ).getUTCDay();

    const contentType =
      allocations[(weekday + 6) % 7];

    stage = "LOAD_HISTORY";

    const {
      data: history,
      error: historyError,
    } = await db
      .from("ai_topic_history")
      .select("topic")
      .eq("brand_id", job.brand_id)
      .order("used_at", {
        ascending: false,
      })
      .limit(80);

    if (historyError) {
      throw historyError;
    }

    stage = "CLAIM_JOB";

    const {
      data: locked,
      error: lockError,
    } = await db
      .from("ai_content_jobs")
      .update({
        status: "generating",
        error_message: null,
        updated_at:
          new Date().toISOString(),
      })
      .eq("id", jobId)
      .in("status", [

        "planned",
        "failed",
      ])
      .select("id")
      .maybeSingle();

    if (lockError || !locked) {
      throw new Error(
        lockError?.message ||
          "Job already processing"
      );
    }

    claimed = true;
    stage = "GENERATE_COPY";

    const textResult = await openai(
      "/responses",
      {
        model: TEXT_MODEL,
        store: false,
        max_output_tokens: 2600,
        input: [
          {
            role: "developer",
            content:
              "你是多品牌高端海报创意总监。" +
              "只输出标准简体中文JSON，" +
              "不使用Markdown。" +
              "不要编造价格、医疗疗效、" +
              "活动、预约资料。" +
              "避免重复主题。" +
              "字段：topic,category," +
              "cover_title,cover_subtitle," +
              "content_title," +
              "knowledge_points(恰好3条)," +
              "caption。" +
              "文字简短适合手机海报。",
          },
          {
            role: "user",
            content: [
              `品牌ID：${job.brand_id}`,
              `日期：${job.content_date}`,
              `类型：${contentType.name}`,
              `类型说明：${
                contentType.description || ""
              }`,
              `类型专属指令：${
                contentType.custom_prompt || ""
              }`,
              `允许价格：${
                contentType.allow_price
                  ? "仅已提供的真实价格"
                  : "不允许"
              }`,
              `允许促销：${
                contentType.allow_promotion
                  ? "仅已提供的真实促销"
                  : "不允许"
              }`,
              `允许预约：${
                contentType.allow_booking_info
                  ? "是"
                  : "不允许"
              }`,
              `品牌总指令：${
                brand.master_prompt
              }`,
              `最近主题：${
                (history || [])
                  .map(
                    (x: any) => x.topic
                  )
                  .join("、")
              }`,
              "封面标题不超过24字，" +
              "副标题不超过38字，" +
              "知识点每条不超过65字。",
            ].join("\n"),
          },
        ],
      },
      apiKey
    );

    const copy = jsonFromAI(
      aiText(textResult)
    );

    if (
      !copy.topic ||
      !copy.cover_title ||
      !copy.content_title ||
      !copy.caption ||
      !Array.isArray(
        copy.knowledge_points
      ) ||
      copy.knowledge_points.length !== 3
    ) {
      throw new Error(
        "AI copy fields incomplete"
      );
    }

    if (
      !contentType.allow_price &&
      /(?:RM\s?\d+|\bMYR\s?\d+)/i.test(
        JSON.stringify(copy)
      )
    ) {
      throw new Error(
        "Price not allowed for this content type"
      );
    }

    stage = "SAVE_TOPIC";

    let topicId = job.topic_id;

    if (!topicId) {
      const normalized =
        String(copy.topic)
          .trim()
          .toLowerCase()
          .replace(/\s+/g, "");

      const {
        data: t,
        error: e,
      } = await db
        .from("ai_topic_history")
        .insert({
          brand_id: job.brand_id,
          topic: copy.topic,
          normalized_topic: normalized,
          category: contentType.name,
        })
        .select("id")
        .single();

      if (e) {
        throw e;
      }

      topicId = t.id;
    }

    const {
      error: checkingError,
    } = await db
      .from("ai_content_jobs")
      .update({
        status: "checking",
        topic_id: topicId,
        updated_at:
          new Date().toISOString(),
      })
      .eq("id", jobId);

    if (checkingError) {
      throw checkingError;
    }

    const variant =
      Number(
        String(job.content_date)
          .replace(/\D/g, "")
      ) || 0;

    const palette =
      PALETTES[
        variant % PALETTES.length
      ];

    // A topic-specific visual illustration, never generic consultation stock photography.
    const common = [
      "Create ONE premium medical wellness EDUCATIONAL ILLUSTRATION for a vertical Chinese social media poster.",
      `TOPIC: ${String(copy.topic).slice(0,100)}.`,
      `HEADLINE CONTEXT: ${String(copy.cover_title).slice(0,100)}.`,

      `KEY EDUCATIONAL FACTS: ${copy.knowledge_points.map((x:unknown)=>String(x)).join("; ").slice(0,420)}.`,
      `Palette: ${palette}.`,
      "Art direction: sophisticated health science magazine, clean accurate simplified anatomy, tasteful physiotherapy/wellness infographic aesthetic, realistic but non-graphic medical illustration.",
      "Show the body region or mechanism directly relevant to this exact topic, not generic people talking, spa rooms or unrelated portraits.",
      "Reserve upper 15 percent and lower 55 percent as quiet low-detail space for separately typeset Chinese title and three educational points.",
      "Place the main topic illustration in the upper-middle 20-55 percent, with elegant editorial framing, fine gold accent details, excellent visual hierarchy.",
      "No text, no Chinese glyphs, no typography, no numbers, no labels, no logo, no watermark, no QR code.",
      "Do not depict incorrect or sensational anatomy; avoid clinical diagnosis or implied guaranteed treatment outcomes.",
      "Single portrait 4:5 poster design background, high-end, original composition."
    ].join(" ");

    stage = "GENERATE_COVER_BACKGROUND";
    const coverBg = await image(common, apiKey);

    const footer =
      job.brand_id ===
      "817e4bb8-8898-46e3-a20a-a29e060de0c3"
        ? "Eco Botanic  |  Nusa Bestari"
        : "";

    // Store original AI backgrounds; the browser will composite typography and logo.
    const prefix = `${job.brand_id}/${job.content_date}/${jobId}`;
    const coverBgPath = `${prefix}/cover-background.png`;
    const coverPath = `${prefix}/cover.png`;

    stage = "UPLOAD_BACKGROUNDS";
    await upload(db, coverBgPath, coverBg);

    stage = "CREATE_SIGNED_UPLOADS";
    const coverSign = await db.storage.from(BUCKET).createSignedUploadUrl(coverPath, { upsert: true });
    if (coverSign.error || !coverSign.data) throw new Error(coverSign.error?.message || "Cover upload token unavailable");

    stage = "SAVE_ASSETS";

    const {
      error: assetError,
    } = await db
      .from("ai_generated_assets")
      .upsert(
        {
          job_id: jobId,
          version: 1,
          caption: copy.caption,
          cover_path: coverPath,
          content_path: null,
          qa_status: "review",
          qa_result: {
            poster_copy: copy,
            content_type_id:
              contentType.id,
            content_type_name:
              contentType.name,
            composition_pending: true,
            cover_background_path: coverBgPath,
            requires_manual_approval: true,
            ready_to_publish: false,
            logo_path: brand.logo_path,
            font_path: FONT_PATH,
            dimensions: {
              width: W,
              height: H,
            },
            text_model: TEXT_MODEL,
            image_model: IMAGE_MODEL,
            generated_at:
              new Date().toISOString(),
          },
        },
        {
          onConflict:
            "job_id,version",
        }
      );

    if (assetError) {
      throw assetError;
    }

    // Stay in checking until the browser uploads the final poster and finalizes.
    return response({
      ok: true,
      job_id: jobId,
      status: "checking",
      cover_background_path: coverBgPath,
      logo_path: brand.logo_path,
      cover_path: coverPath,
      cover_upload_token: coverSign.data.token,
      caption: copy.caption,
      poster_copy: copy,
      message: "Browser composition required; no automatic publishing"
    });
  } catch (e) {
    const message = errText(e);

    console.error(
      "[nd-ai-generate] FAILED",
      {
        stage,
        jobId,
        error: message,
      }
    );

    if (claimed) {
      const {
        error: saveError,
      } = await db
        .from("ai_content_jobs")
        .update({
          status: "failed",
          error_message:
            `${stage}: ${message}`.slice(
              0,
              1000
            ),
          updated_at:
            new Date().toISOString(),
        })
        .eq("id", jobId);

      if (saveError) {
        console.error(
          "Failed to persist job error",
          saveError.message
        );
      }
    }

    return response(
      {
        ok: false,
        stage,
        error: message,
        job_id: jobId,
      },
      500
    );
  }
});
